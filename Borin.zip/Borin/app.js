document.getElementById("signUp").addEventListener("click", signUpMessage);
document.getElementById("login").addEventListener("click", loginMessage);

function signUpMessage() {
    alert(`Sign Up`);
}

function loginMessage() {
    alert(`Login`);
}

